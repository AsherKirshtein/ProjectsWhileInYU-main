The name and login information for all project partners. A brief description of how you divided 
the work between you.

Asher Kirshtein Moshe Wohlberg; 
Asher- Client, README; 

• Design overview: A few simple paragraphs describing the overall structure of your code and any 
important structures.

My implementation is simple, the structure is basically the same but I added some other methods that don't really work and I don't 
really even know what they do. They kind of randomly do different things each time I run it.

• Complete specification: Describe how you handled any ambiguities in the specification. For 
example, how do you implement the ANY policy?

Simple, I didn't

• Known bugs or problems: A list of any features that you did not implement or that you know are 
not working correctly

The Server isn't multithreaded it is just the Original server we were given. I tried to figure it out but it kept breaking so I had to 
just scrap it so I can have a chance to run the Client which also doesn't really work

• Testing: This requirement an aspect that I am very interested in. I will assign points for 
answering these questions. Describe how you tested the functionality of your web server.

I didn't because the server doesn't run correctly 

Describe how can you use the various versions of your extended client to see if the server is 
handing requests concurrently and implementing the FIFO, HPSC, or HPDC policies.

I can't because my server isn't running correctly. So i handle it by closing my eyes and pretending it
doesn't exist.

Specifically, what are the exact parameters one should pass to the client and the server to 
demonstrate that the server is handling requests concurrently? 

The Server isn't running correctly. So......yeah

To demonstrate that the server is correctly running the FIFO policy? the HPSC policy? the HPDC policy? In each case, if your 
client and server are behaving correctly, what output and statistics should you see? 

IDK the server isn't running correctly. My server is not behaving it's being a bad bad server.

But on a serious note, I did spend a lot of time on this but it kept blowing up so I couldn't really 
figure this out. I probably could have eventually gotten the client up but I started working on the client
too late. 